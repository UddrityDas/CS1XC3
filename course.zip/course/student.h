 
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief This function would add a grade to the student profile.
 *
 * @param student 'student' whose grade we are adding
 * @param grade 'grade' which we are adding to the profile
 */
void add_grade(Student *student, double grade);

/**
 * @brief This function would calculate the student's average grade.
 *
 * @param student 'student' whose average grade we are calculating
 * 
 * @return Student Average
 */
double average(Student *student);

/**
 * @brief This function would print a student's profile.
 *
 * @param student 'student' whose information we are printing.
 */
void print_student(Student *student);

/**
 * @brief This function would generate random student's profile.
 *
 * @param grades 'grades' which we are adding to the profile
 * 
 * @return Generated Random Student Profile
 */
Student* generate_random_student(int grades); 
