#include "student.h"
#include <stdbool.h>
 /**
 * @brief abstract data structure that represent a course information
 */
typedef struct _course 
{
  char name[100]; /* the name of the course */
  char code[10];  /* the course code */
  Student *students; /* the students' profile in the course */ 
  int total_students; /* the number of students in the course */
} Course;

/**
 * @brief the information of the student enrolled 
 * 
 * @param course the course in which the student is enrolled
 * @param student the student enrolled
 */
void enroll_student(Course *course, Student *student); 

/**
 * @brief the information of the student enrolled 
 * 
 * @param course the course in which the student is enrolled
 */
void print_course(Course *course);

/**
 * @brief the information of the student enrolled 
 * 
 * @param course the course in which the student is enrolled
 * 
 * @return the top student of the course
 */
Student *top_student(Course* course);

/**
 * @brief the information of the student enrolled 
 * 
 * @param course the course in which the student is enrolled
 * 
 * @return the list students passing the course
 */
Student *passing(Course* course, int *total_passing);