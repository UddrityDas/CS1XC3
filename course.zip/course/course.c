#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
void enroll_student(Course *course, Student *student)
{
  // enrolls a given student to the course
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

void print_course(Course* course)
{
  // prints the course
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // print the students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

Student* top_student(Course* course)
{
  // the top student of the course is null if there is no student
  if (course->total_students == 0) return NULL;
  
  // local variable dictionary
  double student_average = 0; // the student average 
  double max_average = average(&course->students[0]); // the best student average
  Student *student = &course->students[0]; // the student 
 
  // find the top student 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  // return the top student
  return student;
}

Student *passing(Course* course, int *total_passing)
{
  // students passing the course
  int count = 0;
  Student *passing = NULL;
  // find the students who are passing the course
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // create an array for students who are passing
  passing = calloc(count, sizeof(Student));

  // save the students' profile who are passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}